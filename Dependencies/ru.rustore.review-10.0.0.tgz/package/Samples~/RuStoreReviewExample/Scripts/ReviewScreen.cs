using RuStore.Review;
using System;
using UnityEngine;

namespace RuStore.ReviewExample.UI {

    public class ReviewScreen : MonoBehaviour {

        const string CATALOG_APP = "https://www.rustore.ru/catalog/app/";

        [SerializeField]
        private MessageBox _messageBox;

        private void Awake() {
            RuStoreReviewManager.Instance.Init();
        }

        public void RequestReviewFlow() {
            RuStoreReviewManager.Instance.RequestReviewFlow(
                onFailure: (error) => {
                    ShowMessage("Error", string.Format("{0}: {1}", error.name, error.description));
                },
                onSuccess: () => {
                    ShowMessage("Success", "");
                });
        }

        public void LaunchReviewFlow() {
            RuStoreReviewManager.Instance.LaunchReviewFlow(
                onFailure: (error) => {
                    ShowMessage("Error", string.Format("{0}: {1}", error.name, error.description));
                },
                onSuccess: () => {
                });
        }

        public void OpenReviewInRuStore() {
            var url = CATALOG_APP + Application.identifier;
            Application.OpenURL(url);
        }

        private void ShowMessage(string title, string message, Action onClose = null) {
            _messageBox.Show(
                title: title,
                message: message,
                onClose: onClose);
        }
    }
}
